package com.portfolio.pfdiegofranco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PfdiegofrancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
