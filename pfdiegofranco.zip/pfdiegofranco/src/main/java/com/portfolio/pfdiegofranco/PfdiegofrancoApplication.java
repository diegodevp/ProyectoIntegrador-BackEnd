package com.portfolio.pfdiegofranco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PfdiegofrancoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PfdiegofrancoApplication.class, args);
	}

}
